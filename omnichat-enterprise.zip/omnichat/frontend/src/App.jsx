import { useCallback, useEffect, useRef, useState } from 'react';
import { io } from 'socket.io-client';

const API = import.meta.env.VITE_API_URL || 'http://localhost:4000';
const GOOGLE_ID = import.meta.env.VITE_GOOGLE_CLIENT_ID;
const TOKEN_KEY = 'omnichat_token'; // Producción: preferir cookie httpOnly + SameSite para mitigar XSS.

/* ------------------------------ utilidades ------------------------------ */
async function api(path, { method = 'GET', body, token, form } = {}) {
  const res = await fetch(API + path, {
    method,
    headers: { ...(token && { Authorization: `Bearer ${token}` }), ...(body && { 'Content-Type': 'application/json' }) },
    body: form || (body && JSON.stringify(body)),
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw Object.assign(new Error(data.error || 'No se pudo conectar con el servidor'), { status: res.status, code: data.code });
  return data;
}
const money = (cents) => `$${(cents / 100).toFixed(2)}`;
const fmtTime = (ms) => new Date(ms).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
const fmtDate = (ms) => new Date(ms).toLocaleDateString('es', { day: 'numeric', month: 'long', year: 'numeric' });
const fmtSize = (b) => (b > 1048576 ? `${(b / 1048576).toFixed(1)} MB` : `${Math.max(1, Math.round(b / 1024))} KB`);
const daysLeft = (ms) => Math.max(0, Math.ceil((ms - Date.now()) / 86400000));

async function downloadFile(file, token) {
  const res = await fetch(`${API}/api/files/${file.id}/download`, { headers: { Authorization: `Bearer ${token}` } });
  if (!res.ok) return alert('No se pudo descargar el archivo');
  const url = URL.createObjectURL(await res.blob());
  const a = Object.assign(document.createElement('a'), { href: url, download: file.name });
  a.click();
  URL.revokeObjectURL(url);
}

/* ------------------------------ piezas base ------------------------------ */
const btn = 'rounded-lg px-4 py-2.5 text-sm font-semibold transition-colors disabled:opacity-50';
const btnPrimary = `${btn} bg-teal-600 text-white hover:bg-teal-700`;
const btnGhost = `${btn} border border-ink-200 text-ink-800 hover:bg-ink-100`;
const input = 'w-full rounded-lg border border-ink-200 bg-white px-3 py-2.5 text-sm placeholder:text-ink-400';

function Logo({ light }) {
  return (
    <div className="flex items-center gap-2.5">
      <svg width="28" height="28" viewBox="0 0 28 28" aria-hidden="true">
        <rect width="28" height="28" rx="8" fill="#0E8C87" />
        <path d="M8 10.5a2.5 2.5 0 0 1 2.5-2.5h7a2.5 2.5 0 0 1 2.5 2.5v4a2.5 2.5 0 0 1-2.5 2.5H14l-3.5 3v-3A2.5 2.5 0 0 1 8 14.5z" fill="#fff" />
      </svg>
      <span className={`text-lg font-bold tracking-tight ${light ? 'text-white' : 'text-ink-950'}`}>OmniChat</span>
    </div>
  );
}
const Field = ({ label, ...p }) => (
  <label className="block">
    <span className="mb-1 block text-sm font-medium text-ink-800">{label}</span>
    <input className={input} {...p} />
  </label>
);
const ErrorBox = ({ children }) =>
  children ? <p role="alert" className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">{children}</p> : null;

/* ------------------------------ landing ------------------------------ */
function Landing({ onLogin, onRegister }) {
  const features = [
    ['Canales por departamento', 'Ventas, Soporte, Gerencia o cada proyecto tienen su propio canal. Los canales privados solo los ven administradores.'],
    ['Archivos sin fricción', 'Comparte PDF, Word, Excel, imágenes y comprimidos de hasta 50 MB. Quedan en el historial del canal.'],
    ['Videollamadas y soporte remoto', 'Reuniones internas o con clientes en el navegador. Comparte tu pantalla para guiar una reparación o una demo en directo.'],
    ['Datos aislados por empresa', 'Canales, mensajes y archivos de tu empresa son invisibles para cualquier otra organización.'],
  ];
  return (
    <div className="min-h-screen">
      <header className="mx-auto flex max-w-6xl items-center justify-between px-6 py-5">
        <Logo />
        <nav className="flex items-center gap-2">
          <button className={btnGhost} onClick={onLogin}>Iniciar sesión</button>
          <button className={btnPrimary} onClick={onRegister}>Probar 14 días gratis</button>
        </nav>
      </header>

      <section className="mx-auto grid max-w-6xl items-center gap-12 px-6 pb-20 pt-10 lg:grid-cols-[1.05fr_1fr]">
        <div>
          <h1 className="text-4xl font-extrabold leading-[1.08] tracking-tight sm:text-5xl lg:text-6xl">
            La conversación de toda tu empresa, en un solo lugar.
          </h1>
          <p className="mt-6 max-w-xl text-lg leading-relaxed text-ink-600">
            Chat por departamentos, archivos y videollamadas para equipos de cualquier tamaño y sector. Un precio por empresa, no por persona.
          </p>
          <div className="mt-8 flex flex-wrap items-center gap-4">
            <button className={`${btnPrimary} px-6 py-3 text-base`} onClick={onRegister}>Crear mi empresa</button>
            <p className="text-sm text-ink-600"><b className="text-ink-950">{money(500)} al mes</b> por empresa · 14 días gratis</p>
          </div>
        </div>

        {/* vista previa del producto */}
        <div className="overflow-hidden rounded-2xl border border-ink-200 bg-white shadow-xl" aria-hidden="true">
          <div className="flex items-center justify-between border-b border-ink-100 bg-ink-950 px-4 py-3 text-white">
            <span className="text-sm font-semibold"># ventas</span>
            <span className="rounded-full bg-signal px-2.5 py-0.5 text-xs font-semibold text-ink-950">Llamada en curso</span>
          </div>
          <div className="space-y-4 p-5 text-sm">
            {[['Lucía', 'Cerramos la propuesta con Alvarez & Hijos. Subo el contrato.'], ['Marcos', 'Perfecto, lo reviso antes de la reunión de las 16.']].map(([n, t]) => (
              <div key={n} className="flex gap-3">
                <span className="grid h-8 w-8 shrink-0 place-items-center rounded-full bg-teal-500 text-xs font-bold text-white">{n[0]}</span>
                <div><b>{n}</b><p className="text-ink-600">{t}</p></div>
              </div>
            ))}
            <div className="ml-11 flex w-fit items-center gap-3 rounded-lg border border-ink-200 px-3 py-2">
              <span className="rounded bg-red-100 px-1.5 py-0.5 text-xs font-bold text-red-700">PDF</span>
              <span>Contrato-Alvarez.pdf</span><span className="text-ink-400">1.8 MB</span>
            </div>
            <div className="grid grid-cols-3 gap-2 pt-1">
              {['bg-ink-800', 'bg-teal-700', 'bg-ink-600'].map((c, i) => <div key={i} className={`aspect-video rounded-lg ${c}`} />)}
            </div>
          </div>
        </div>
      </section>

      <section className="border-y border-ink-200 bg-white">
        <dl className="mx-auto grid max-w-6xl gap-x-12 px-6 py-16 md:grid-cols-2">
          {features.map(([t, d]) => (
            <div key={t} className="border-t border-ink-200 py-6 first:border-t-0 md:[&:nth-child(2)]:border-t-0">
              <dt className="text-lg font-bold">{t}</dt>
              <dd className="mt-2 max-w-md leading-relaxed text-ink-600">{d}</dd>
            </div>
          ))}
        </dl>
      </section>

      <section className="mx-auto max-w-6xl px-6 py-20">
        <div className="flex flex-col items-start justify-between gap-8 rounded-2xl bg-ink-950 p-10 text-white md:flex-row md:items-center">
          <div>
            <p className="text-5xl font-extrabold">{money(500)}<span className="text-xl font-medium text-ink-200"> USD / mes</span></p>
            <p className="mt-3 max-w-md text-ink-200">Toda la empresa, usuarios ilimitados. Empiezas con 14 días de prueba; al terminar, agregas una tarjeta para seguir.</p>
          </div>
          <button className={`${btn} bg-signal px-6 py-3 text-base text-ink-950 hover:bg-amber-400`} onClick={onRegister}>Empezar la prueba gratis</button>
        </div>
      </section>
      <footer className="px-6 pb-10 text-center text-sm text-ink-400">© {new Date().getFullYear()} OmniChat Enterprise</footer>
    </div>
  );
}

/* ------------------------------ autenticación ------------------------------ */
function GoogleButton({ onToken }) {
  const ref = useRef(null);
  const cb = useRef(onToken);
  cb.current = onToken;
  useEffect(() => {
    if (!GOOGLE_ID) return;
    const init = () => {
      window.google.accounts.id.initialize({ client_id: GOOGLE_ID, callback: (r) => cb.current(r.credential) });
      window.google.accounts.id.renderButton(ref.current, { theme: 'outline', size: 'large', width: 320, text: 'continue_with' });
    };
    if (window.google?.accounts) return init();
    const s = Object.assign(document.createElement('script'), { src: 'https://accounts.google.com/gsi/client', async: true, onload: init });
    document.head.appendChild(s);
  }, []);
  if (!GOOGLE_ID) return <p className="rounded-lg bg-amber-50 px-3 py-2 text-sm text-amber-800">Define VITE_GOOGLE_CLIENT_ID en frontend/.env para activar Google.</p>;
  return <div ref={ref} className="flex justify-center" />;
}

function AuthScreen({ initialMode, onSession, onBack }) {
  const [mode, setMode] = useState(initialMode);
  const [method, setMethod] = useState('email');
  const [f, setF] = useState({ name: '', email: '', password: '', phone: '', code: '', companyName: '', inviteCode: '', join: false });
  const [otpSent, setOtpSent] = useState(false);
  const [needsSetup, setNeedsSetup] = useState(false);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [devCode, setDevCode] = useState('');
  const googleTok = useRef(null);
  const showSetup = mode === 'register' || needsSetup;
  const fr = useRef(f);
  fr.current = { ...f, showSetup };
  const set = (k) => (e) => setF({ ...f, [k]: e.target.value });

  const setupFields = () => {
    const v = fr.current, o = {};
    if (!v.showSetup) return o;
    if (v.join) { if (v.inviteCode) o.inviteCode = v.inviteCode; } else if (v.companyName) o.companyName = v.companyName;
    return o;
  };
  const run = async (fn) => {
    setBusy(true); setError('');
    try {
      const r = await fn();
      if (r?.token) { localStorage.setItem(TOKEN_KEY, r.token); onSession(r); }
    } catch (e) {
      if (e.code === 'NEEDS_SETUP') { setNeedsSetup(true); setError('Es tu primera vez aquí: completa los datos de tu empresa para crear la cuenta.'); }
      else setError(e.message);
    } finally { setBusy(false); }
  };
  const loginGoogle = (idToken) => { googleTok.current = idToken; run(() => api('/api/auth/google', { method: 'POST', body: { idToken, ...setupFields() } })); };

  const submit = (e) => {
    e.preventDefault();
    const v = fr.current;
    if (method === 'email')
      return run(() => mode === 'login'
        ? api('/api/auth/login', { method: 'POST', body: { email: v.email, password: v.password } })
        : api('/api/auth/register', { method: 'POST', body: { name: v.name, email: v.email, password: v.password, ...setupFields() } }));
    if (method === 'phone') {
      if (!otpSent)
        return run(async () => { const r = await api('/api/auth/phone/request', { method: 'POST', body: { phone: v.phone } }); setOtpSent(true); setDevCode(r.devCode || ''); });
      return run(() => api('/api/auth/phone/verify', { method: 'POST', body: { phone: v.phone, code: v.code, ...(v.showSetup && v.name ? { name: v.name } : {}), ...setupFields() } }));
    }
    if (googleTok.current) loginGoogle(googleTok.current);
  };

  const tabs = [['email', 'Correo'], ['phone', 'Teléfono'], ['google', 'Google']];
  const setupBlock = showSetup && (
    <div className="space-y-3 rounded-lg bg-ink-100 p-4">
      <div className="flex gap-2 text-sm">
        {[[false, 'Crear empresa'], [true, 'Unirme con código']].map(([j, l]) => (
          <button type="button" key={l} onClick={() => setF({ ...f, join: j })}
            className={`rounded-md px-3 py-1.5 font-medium ${f.join === j ? 'bg-white shadow-sm' : 'text-ink-600'}`}>{l}</button>
        ))}
      </div>
      {f.join
        ? <Field label="Código de invitación" value={f.inviteCode} onChange={set('inviteCode')} placeholder="A1B2C3D4E5" />
        : <Field label="Nombre de la empresa" value={f.companyName} onChange={set('companyName')} placeholder="Distribuidora Norte S.A." />}
    </div>
  );

  return (
    <div className="grid min-h-screen place-items-center px-4 py-10">
      <div className="w-full max-w-md">
        <button onClick={onBack} className="mb-6 text-sm text-ink-600 hover:underline">← Volver</button>
        <div className="rounded-2xl border border-ink-200 bg-white p-8 shadow-sm">
          <Logo />
          <h1 className="mt-6 text-2xl font-bold">{mode === 'login' ? 'Inicia sesión' : 'Crea tu empresa en OmniChat'}</h1>
          {mode === 'register' && <p className="mt-1 text-sm text-ink-600">14 días gratis, sin tarjeta.</p>}

          <div role="tablist" className="mt-6 grid grid-cols-3 rounded-lg bg-ink-100 p-1 text-sm font-medium">
            {tabs.map(([k, l]) => (
              <button key={k} role="tab" aria-selected={method === k} onClick={() => { setMethod(k); setError(''); }}
                className={`rounded-md py-2 ${method === k ? 'bg-white shadow-sm' : 'text-ink-600'}`}>{l}</button>
            ))}
          </div>

          <form onSubmit={submit} className="mt-5 space-y-4">
            {method === 'email' && (<>
              {mode === 'register' && <Field label="Tu nombre" value={f.name} onChange={set('name')} required />}
              <Field label="Correo corporativo" type="email" autoComplete="email" value={f.email} onChange={set('email')} required />
              <Field label="Contraseña" type="password" autoComplete={mode === 'login' ? 'current-password' : 'new-password'}
                value={f.password} onChange={set('password')} minLength={mode === 'register' ? 8 : undefined} required />
              {setupBlock}
            </>)}

            {method === 'phone' && (<>
              <Field label="Teléfono (formato internacional)" type="tel" placeholder="+5493511234567" value={f.phone} onChange={set('phone')} required />
              {otpSent && (<>
                <Field label="Código de 6 dígitos" inputMode="numeric" maxLength={6} value={f.code} onChange={set('code')} required />
                {devCode && <p className="text-xs text-ink-600">Modo desarrollo — tu código es <b>{devCode}</b></p>}
                {showSetup && <Field label="Tu nombre" value={f.name} onChange={set('name')} required />}
                {setupBlock}
              </>)}
            </>)}

            {method === 'google' && (<>
              {setupBlock}
              <GoogleButton onToken={loginGoogle} />
            </>)}

            <ErrorBox>{error}</ErrorBox>
            {(method !== 'google' || (needsSetup && googleTok.current)) && (
              <button className={`${btnPrimary} w-full`} disabled={busy}>
                {busy ? 'Un momento…' : method === 'phone' && !otpSent ? 'Enviar código'
                  : mode === 'login' && !needsSetup ? 'Entrar' : 'Crear cuenta'}
              </button>
            )}
          </form>

          <p className="mt-6 text-center text-sm text-ink-600">
            {mode === 'login' ? '¿Tu empresa aún no usa OmniChat?' : '¿Ya tienes cuenta?'}{' '}
            <button className="font-semibold text-teal-600 hover:underline"
              onClick={() => { setMode(mode === 'login' ? 'register' : 'login'); setNeedsSetup(false); setError(''); }}>
              {mode === 'login' ? 'Crea una empresa' : 'Inicia sesión'}
            </button>
          </p>
        </div>
      </div>
    </div>
  );
}

/* ------------------------------ cobro ------------------------------ */
function Billing({ session, onCompany, onLogout, onClose }) {
  const { token, user, company } = session;
  const [card, setCard] = useState({ holder: '', cardNumber: '', exp: '', cvc: '' });
  const [payments, setPayments] = useState([]);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const isOwner = user.role === 'owner';
  const active = company.status === 'active' || company.status === 'canceled';

  useEffect(() => { api('/api/billing/status', { token }).then((r) => setPayments(r.payments)).catch(() => {}); }, [token, company.status]);

  const pay = async (e) => {
    e.preventDefault(); setBusy(true); setError('');
    try { const r = await api('/api/billing/subscribe', { method: 'POST', token, body: card }); onCompany(r.company); setCard({ holder: '', cardNumber: '', exp: '', cvc: '' }); }
    catch (err) { setError(err.message); } finally { setBusy(false); }
  };
  const cancel = async () => {
    if (!confirm('¿Cancelar la renovación? Seguirás con acceso hasta el fin del período pagado.')) return;
    onCompany((await api('/api/billing/cancel', { method: 'POST', token })).company);
  };

  const headline = company.access.ok && company.status === 'trial'
    ? `Te quedan ${daysLeft(company.trialEndsAt)} días de prueba`
    : active ? 'Tu suscripción está activa'
    : company.status === 'past_due' ? 'No pudimos cobrar tu última renovación' : 'Tu prueba gratuita terminó';

  return (
    <div className="min-h-screen px-4 py-10">
      <div className="mx-auto max-w-4xl">
        <div className="mb-8 flex items-center justify-between">
          <Logo />
          <div className="flex gap-2">
            {company.access.ok && <button className={btnGhost} onClick={onClose}>Volver al chat</button>}
            <button className={btnGhost} onClick={onLogout}>Cerrar sesión</button>
          </div>
        </div>
        <h1 className="text-3xl font-extrabold tracking-tight">{headline}</h1>
        <p className="mt-2 text-ink-600">
          {active ? `Próxima renovación: ${fmtDate(company.currentPeriodEnd)}${company.status === 'canceled' ? ' (cancelada, no se renovará)' : ''}.`
            : 'Para seguir usando OmniChat, activa la suscripción de tu empresa. Tus canales, mensajes y archivos siguen guardados.'}
        </p>

        <div className="mt-8 grid gap-8 md:grid-cols-[1fr_1.2fr]">
          <div className="rounded-2xl bg-ink-950 p-8 text-white">
            <p className="text-5xl font-extrabold">{money(company.priceCents)}</p>
            <p className="text-ink-200">USD por mes · por empresa</p>
            <ul className="mt-6 space-y-2 text-sm text-ink-200">
              <li>Usuarios ilimitados</li><li>Canales por departamento</li><li>Archivos de hasta 50 MB</li><li>Videollamadas y pantalla compartida</li>
            </ul>
            {active && <p className="mt-6 text-sm">Tarjeta: {company.cardBrand} ···· {company.cardLast4}</p>}
          </div>

          <div className="rounded-2xl border border-ink-200 bg-white p-8">
            {isOwner ? (
              <form onSubmit={pay} className="space-y-4">
                <h2 className="text-lg font-bold">{active ? 'Cambiar tarjeta' : 'Datos de la tarjeta'}</h2>
                <Field label="Titular" value={card.holder} onChange={(e) => setCard({ ...card, holder: e.target.value })} autoComplete="cc-name" required />
                <Field label="Número de tarjeta" inputMode="numeric" autoComplete="cc-number" placeholder="4242 4242 4242 4242" value={card.cardNumber}
                  onChange={(e) => setCard({ ...card, cardNumber: e.target.value.replace(/\D/g, '').slice(0, 19).replace(/(.{4})/g, '$1 ').trim() })} required />
                <div className="grid grid-cols-2 gap-4">
                  <Field label="Vencimiento" placeholder="MM/AA" autoComplete="cc-exp" value={card.exp}
                    onChange={(e) => { const d = e.target.value.replace(/\D/g, '').slice(0, 4); setCard({ ...card, exp: d.length > 2 ? `${d.slice(0, 2)}/${d.slice(2)}` : d }); }} required />
                  <Field label="CVC" inputMode="numeric" autoComplete="cc-csc" maxLength={4} value={card.cvc}
                    onChange={(e) => setCard({ ...card, cvc: e.target.value.replace(/\D/g, '') })} required />
                </div>
                <ErrorBox>{error}</ErrorBox>
                <button className={`${btnPrimary} w-full`} disabled={busy}>{busy ? 'Procesando…' : `Pagar ${money(company.priceCents)} y activar`}</button>
                <p className="text-xs text-ink-400">Pasarela simulada. Prueba con 4242 4242 4242 4242 (aprobada) o 4000 0000 0000 0002 (rechazada), cualquier fecha futura.</p>
                {company.status === 'active' && <button type="button" onClick={cancel} className="text-sm text-red-600 hover:underline">Cancelar renovación</button>}
              </form>
            ) : (
              <p className="text-ink-600">Solo el propietario de la empresa puede gestionar la suscripción. Pídele que active el plan para que todos recuperen el acceso.</p>
            )}
          </div>
        </div>

        {payments.length > 0 && (
          <div className="mt-10">
            <h2 className="mb-3 text-lg font-bold">Historial de pagos</h2>
            <ul className="divide-y divide-ink-200 rounded-xl border border-ink-200 bg-white text-sm">
              {payments.map((p) => (
                <li key={p.id} className="flex justify-between px-4 py-3">
                  <span>{fmtDate(p.created_at)}</span><span>{money(p.amount_cents)}</span>
                  <span className={p.status === 'succeeded' ? 'text-teal-600' : 'text-red-600'}>{p.status === 'succeeded' ? 'Pagado' : 'Fallido'}</span>
                </li>
              ))}
            </ul>
          </div>
        )}
      </div>
    </div>
  );
}

/* ------------------------------ videollamada (WebRTC) ------------------------------ */
// Malla P2P (hasta 8 personas). Para salas grandes o redes restrictivas añade TURN (coturn) y/o un SFU (LiveKit, mediasoup).
const ICE = { iceServers: [{ urls: 'stun:stun.l.google.com:19302' }] };

function Tile({ stream, name, muted, contain }) {
  const ref = useRef(null);
  useEffect(() => { if (ref.current) ref.current.srcObject = stream; }, [stream]);
  return (
    <div className="relative aspect-video overflow-hidden rounded-lg bg-ink-950">
      <video ref={ref} autoPlay playsInline muted={muted} className={`h-full w-full ${contain ? 'object-contain' : 'object-cover'}`} />
      <span className="absolute bottom-2 left-2 rounded bg-ink-950/70 px-2 py-0.5 text-xs text-white">{name}</span>
    </div>
  );
}

function CallPanel({ socket, channel, user, onClose }) {
  const [peers, setPeers] = useState({});
  const [local, setLocal] = useState(null);
  const [mic, setMic] = useState(true);
  const [cam, setCam] = useState(true);
  const [sharing, setSharing] = useState(false);
  const [err, setErr] = useState('');
  const pcs = useRef({});
  const media = useRef(null);
  const screen = useRef(null);

  useEffect(() => {
    let stopped = false;
    const createPc = (id, name) => {
      const pc = new RTCPeerConnection(ICE);
      pcs.current[id] = pc;
      media.current.getTracks().forEach((t) => pc.addTrack(t, media.current));
      pc.onicecandidate = (e) => e.candidate && socket.emit('call:signal', { to: id, data: { candidate: e.candidate } });
      pc.ontrack = (e) => setPeers((p) => ({ ...p, [id]: { name, stream: e.streams[0] } }));
      return pc;
    };
    const onSignal = async ({ from, name, data }) => {
      try {
        const pc = pcs.current[from] || createPc(from, name);
        if (data.sdp) {
          await pc.setRemoteDescription(data.sdp);
          if (data.sdp.type === 'offer') {
            await pc.setLocalDescription(await pc.createAnswer());
            socket.emit('call:signal', { to: from, data: { sdp: pc.localDescription } });
          }
        } else if (data.candidate) await pc.addIceCandidate(data.candidate);
      } catch (e) { console.warn('señalización', e); }
    };
    const onLeft = (id) => {
      pcs.current[id]?.close(); delete pcs.current[id];
      setPeers((p) => { const n = { ...p }; delete n[id]; return n; });
    };

    (async () => {
      try { media.current = await navigator.mediaDevices.getUserMedia({ video: true, audio: true }); }
      catch { try { media.current = await navigator.mediaDevices.getUserMedia({ audio: true }); setCam(false); }
              catch { return setErr('No se pudo acceder a la cámara ni al micrófono. Revisa los permisos del navegador.'); } }
      if (stopped) return media.current.getTracks().forEach((t) => t.stop());
      setLocal(media.current);
      socket.on('call:signal', onSignal);
      socket.on('call:peer-left', onLeft);
      socket.emit('call:join', { channelId: channel.id }, async (res) => {
        if (res?.error) return setErr(res.error);
        for (const p of res.peers) {
          const pc = createPc(p.id, p.name);
          await pc.setLocalDescription(await pc.createOffer());
          socket.emit('call:signal', { to: p.id, data: { sdp: pc.localDescription } });
        }
      });
    })();

    return () => {
      stopped = true;
      socket.off('call:signal', onSignal); socket.off('call:peer-left', onLeft);
      socket.emit('call:leave');
      Object.values(pcs.current).forEach((pc) => pc.close()); pcs.current = {};
      media.current?.getTracks().forEach((t) => t.stop());
      screen.current?.getTracks().forEach((t) => t.stop());
    };
  }, [socket, channel.id]);

  const toggle = (kind, setter) => {
    const tracks = kind === 'audio' ? media.current?.getAudioTracks() : media.current?.getVideoTracks();
    tracks?.forEach((t) => (t.enabled = !t.enabled));
    setter(!!tracks?.[0]?.enabled);
  };
  const swapVideo = (track) => Object.values(pcs.current).forEach((pc) => pc.getSenders().find((s) => s.track?.kind === 'video')?.replaceTrack(track));
  const stopShare = () => {
    screen.current?.getTracks().forEach((t) => t.stop()); screen.current = null;
    swapVideo(media.current.getVideoTracks()[0] || null); setLocal(media.current); setSharing(false);
  };
  const share = async () => {
    if (sharing) return stopShare();
    try {
      screen.current = await navigator.mediaDevices.getDisplayMedia({ video: true });
      const track = screen.current.getVideoTracks()[0];
      track.onended = stopShare; swapVideo(track); setLocal(screen.current); setSharing(true);
    } catch { /* el usuario canceló */ }
  };

  const entries = Object.entries(peers);
  return (
    <div className="flex flex-col border-b border-ink-800 bg-ink-900 p-4">
      <div className={`grid gap-3 ${entries.length > 1 ? 'grid-cols-2 lg:grid-cols-3' : 'grid-cols-2'}`}>
        {local && <Tile stream={local} name={sharing ? 'Tu pantalla' : `${user.name} (tú)`} muted contain={sharing} />}
        {entries.map(([id, p]) => <Tile key={id} stream={p.stream} name={p.name} />)}
      </div>
      {err && <p className="mt-3 text-sm text-red-300">{err}</p>}
      {!err && entries.length === 0 && <p className="mt-3 text-sm text-ink-400">Esperando a que alguien más se una a #{channel.name}…</p>}
      <div className="mt-3 flex flex-wrap gap-2 text-sm">
        <button className={`${btn} bg-ink-800 text-white hover:bg-ink-600`} onClick={() => toggle('audio', setMic)}>{mic ? 'Silenciar' : 'Activar micrófono'}</button>
        <button className={`${btn} bg-ink-800 text-white hover:bg-ink-600`} onClick={() => toggle('video', setCam)}>{cam ? 'Apagar cámara' : 'Encender cámara'}</button>
        <button className={`${btn} ${sharing ? 'bg-signal text-ink-950' : 'bg-ink-800 text-white hover:bg-ink-600'}`} onClick={share}>
          {sharing ? 'Dejar de compartir' : 'Compartir pantalla (soporte remoto)'}
        </button>
        <button className={`${btn} ml-auto bg-red-600 text-white hover:bg-red-700`} onClick={onClose}>Salir de la llamada</button>
      </div>
    </div>
  );
}

/* ------------------------------ espacio de trabajo (chat) ------------------------------ */
function Workspace({ session, onLogout, onBilling, onExpired }) {
  const { token, user, company } = session;
  const [channels, setChannels] = useState([]);
  const [active, setActive] = useState(null);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [typing, setTyping] = useState('');
  const [unread, setUnread] = useState({});
  const [inCall, setInCall] = useState(false);
  const [callBanner, setCallBanner] = useState(null);
  const [uploading, setUploading] = useState(false);
  const [error, setError] = useState('');
  const [newCh, setNewCh] = useState(null);
  const socketRef = useRef(null);
  const [socket, setSocket] = useState(null);
  const activeRef = useRef(null);
  const endRef = useRef(null);
  const typingTimer = useRef(null);
  const lastTyping = useRef(0);
  activeRef.current = active;

  const handle = useCallback((e) => { if (e.code === 'SUBSCRIPTION_REQUIRED') onExpired(); else setError(e.message); }, [onExpired]);

  useEffect(() => { api('/api/channels', { token }).then((c) => { setChannels(c); setActive((a) => a || c[0] || null); }).catch(handle); }, [token, handle]);

  useEffect(() => {
    const s = io(API, { auth: { token } });
    socketRef.current = s; setSocket(s);
    s.on('message:new', (m) => {
      if (m.channelId === activeRef.current?.id) setMessages((prev) => (prev.some((x) => x.id === m.id) ? prev : [...prev, m]));
      else setUnread((u) => ({ ...u, [m.channelId]: (u[m.channelId] || 0) + 1 }));
    });
    s.on('channel:created', (c) => setChannels((prev) => (prev.some((x) => x.id === c.id) ? prev : [...prev, c])));
    s.on('typing', ({ channelId, userName }) => {
      if (channelId !== activeRef.current?.id) return;
      setTyping(`${userName} está escribiendo…`);
      clearTimeout(typingTimer.current); typingTimer.current = setTimeout(() => setTyping(''), 2000);
    });
    s.on('call:started', ({ channelId, by }) => setCallBanner({ channelId, by }));
    return () => s.disconnect();
  }, [token]);

  useEffect(() => {
    if (!active) return;
    setMessages([]); setTyping(''); setUnread((u) => ({ ...u, [active.id]: 0 }));
    socketRef.current?.emit('channel:join', active.id, (r) => r?.error === 'SUBSCRIPTION_REQUIRED' && onExpired());
    api(`/api/channels/${active.id}/messages`, { token }).then(setMessages).catch(handle);
  }, [active?.id, token]); // eslint-disable-line

  useEffect(() => { endRef.current?.scrollIntoView({ behavior: 'smooth' }); }, [messages]);

  const send = (e) => {
    e.preventDefault();
    const body = text.trim();
    if (!body || !active) return;
    socketRef.current.emit('message:send', { channelId: active.id, body }, (r) => r?.error && (r.error === 'SUBSCRIPTION_REQUIRED' ? onExpired() : setError(r.error)));
    setText('');
  };
  const onType = (e) => {
    setText(e.target.value);
    if (Date.now() - lastTyping.current > 1500) { lastTyping.current = Date.now(); socketRef.current?.emit('typing', active.id); }
  };
  const upload = async (e) => {
    const file = e.target.files[0]; e.target.value = '';
    if (!file || !active) return;
    const form = new FormData(); form.append('file', file);
    setUploading(true); setError('');
    try { await api(`/api/channels/${active.id}/files`, { method: 'POST', token, form }); } catch (err) { handle(err); } finally { setUploading(false); }
  };
  const createChannel = async (e) => {
    e.preventDefault();
    try {
      const c = await api('/api/channels', { method: 'POST', token, body: newCh });
      setNewCh(null); setActive(c);
    } catch (err) { handle(err); }
  };

  const byDept = channels.reduce((acc, c) => ((acc[c.department] ||= []).push(c), acc), {});
  const isAdmin = user.role !== 'member';
  const trialLeft = company.status === 'trial' ? daysLeft(company.trialEndsAt) : null;

  return (
    <div className="flex h-screen flex-col">
      {(trialLeft !== null || company.status === 'past_due') && (
        <div className="flex items-center justify-center gap-3 bg-signal px-4 py-1.5 text-sm font-medium text-ink-950">
          {company.status === 'past_due' ? 'No pudimos cobrar tu renovación.' : `Prueba gratuita: ${trialLeft} ${trialLeft === 1 ? 'día restante' : 'días restantes'}.`}
          {user.role === 'owner' && <button className="underline" onClick={onBilling}>Activar suscripción</button>}
        </div>
      )}
      <div className="flex min-h-0 flex-1">
        <aside className="hidden w-64 shrink-0 flex-col bg-ink-950 text-ink-200 md:flex">
          <div className="border-b border-ink-800 p-4"><Logo light /><p className="mt-3 truncate text-sm font-semibold text-white">{company.name}</p></div>
          <nav className="flex-1 overflow-y-auto p-3">
            {Object.entries(byDept).map(([dept, list]) => (
              <div key={dept} className="mb-4">
                <p className="px-2 pb-1 text-xs font-semibold text-ink-400">{dept}</p>
                {list.map((c) => (
                  <button key={c.id} onClick={() => setActive(c)}
                    className={`flex w-full items-center justify-between rounded-md px-2 py-1.5 text-left text-sm ${active?.id === c.id ? 'bg-teal-600 text-white' : 'hover:bg-ink-800'}`}>
                    <span># {c.name}{c.is_private ? ' 🔒' : ''}</span>
                    {unread[c.id] > 0 && <span className="rounded-full bg-signal px-1.5 text-xs font-bold text-ink-950">{unread[c.id]}</span>}
                  </button>
                ))}
              </div>
            ))}
            {isAdmin && (newCh ? (
              <form onSubmit={createChannel} className="space-y-2 rounded-md bg-ink-900 p-2">
                <input className="w-full rounded bg-ink-800 px-2 py-1 text-sm text-white" placeholder="nombre-del-canal" value={newCh.name} onChange={(e) => setNewCh({ ...newCh, name: e.target.value })} required />
                <input className="w-full rounded bg-ink-800 px-2 py-1 text-sm text-white" placeholder="Departamento" value={newCh.department} onChange={(e) => setNewCh({ ...newCh, department: e.target.value })} required />
                <label className="flex items-center gap-2 text-xs"><input type="checkbox" onChange={(e) => setNewCh({ ...newCh, isPrivate: e.target.checked })} /> Privado (solo administradores)</label>
                <div className="flex gap-2"><button className="rounded bg-teal-600 px-2 py-1 text-xs text-white">Crear canal</button><button type="button" className="text-xs" onClick={() => setNewCh(null)}>Cancelar</button></div>
              </form>
            ) : <button className="px-2 text-sm text-ink-400 hover:text-white" onClick={() => setNewCh({ name: '', department: 'General', isPrivate: false })}>+ Nuevo canal</button>)}
          </nav>
          <div className="border-t border-ink-800 p-4 text-sm">
            <p className="truncate font-medium text-white">{user.name}</p>
            <p className="truncate text-xs text-ink-400">{user.email || user.phone}</p>
            {isAdmin && company.inviteCode && <p className="mt-2 text-xs">Código de invitación: <b className="select-all text-white">{company.inviteCode}</b></p>}
            <div className="mt-3 flex gap-3 text-xs">
              {user.role === 'owner' && <button className="hover:text-white" onClick={onBilling}>Facturación</button>}
              <button className="hover:text-white" onClick={onLogout}>Salir</button>
            </div>
          </div>
        </aside>

        <main className="flex min-w-0 flex-1 flex-col bg-white">
          <header className="flex items-center justify-between border-b border-ink-200 px-5 py-3">
            <h1 className="font-bold"># {active?.name || '…'} <span className="ml-2 text-sm font-normal text-ink-400">{active?.department}</span></h1>
            <button className={btnPrimary} disabled={!active || inCall} onClick={() => { setInCall(true); setCallBanner(null); }}>Videollamada</button>
          </header>

          {callBanner && callBanner.channelId === active?.id && !inCall && (
            <div className="flex items-center justify-between bg-teal-50 px-5 py-2 text-sm">
              <span>{callBanner.by} inició una llamada en este canal.</span>
              <button className="font-semibold text-teal-700 hover:underline" onClick={() => { setInCall(true); setCallBanner(null); }}>Unirme</button>
            </div>
          )}
          {inCall && active && socket && <CallPanel socket={socket} channel={active} user={user} onClose={() => setInCall(false)} />}

          <div className="flex-1 space-y-4 overflow-y-auto px-5 py-4">
            {messages.length === 0 && <p className="text-sm text-ink-400">Este canal está vacío. Escribe el primer mensaje o comparte un archivo.</p>}
            {messages.map((m) => (
              <div key={m.id} className="flex gap-3">
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-full bg-teal-500 text-sm font-bold text-white">{m.userName[0]?.toUpperCase()}</span>
                <div className="min-w-0">
                  <p className="text-sm"><b>{m.userName}</b> <span className="text-xs text-ink-400">{fmtTime(m.createdAt)}</span></p>
                  {m.body && <p className="whitespace-pre-wrap break-words text-[15px]">{m.body}</p>}
                  {m.file && (
                    <button onClick={() => downloadFile(m.file, token)} className="mt-1 flex items-center gap-3 rounded-lg border border-ink-200 px-3 py-2 text-left text-sm hover:bg-ink-100">
                      <span className="font-medium">{m.file.name}</span><span className="text-ink-400">{fmtSize(m.file.size)}</span><span className="font-semibold text-teal-600">Descargar</span>
                    </button>
                  )}
                </div>
              </div>
            ))}
            <div ref={endRef} />
          </div>

          <div className="border-t border-ink-200 p-4">
            <p className="h-5 text-xs text-ink-400">{typing}{uploading && 'Subiendo archivo…'}</p>
            {error && <div className="mb-2"><ErrorBox>{error}</ErrorBox></div>}
            <form onSubmit={send} className="flex gap-2">
              <label className={`${btnGhost} cursor-pointer`}>
                Adjuntar<input type="file" className="sr-only" onChange={upload} disabled={uploading || !active} />
              </label>
              <input className={input} value={text} onChange={onType} placeholder={`Escribe en #${active?.name || ''}`} maxLength={4000} disabled={!active} />
              <button className={btnPrimary} disabled={!text.trim()}>Enviar</button>
            </form>
          </div>
        </main>
      </div>
    </div>
  );
}

/* ------------------------------ raíz ------------------------------ */
export default function App() {
  const [session, setSession] = useState(null);
  const [booting, setBooting] = useState(!!localStorage.getItem(TOKEN_KEY));
  const [view, setView] = useState('landing'); // landing | login | register
  const [billingOpen, setBillingOpen] = useState(false);

  const refresh = useCallback(async () => {
    const token = localStorage.getItem(TOKEN_KEY);
    if (!token) return;
    const r = await api('/api/me', { token });
    setSession({ token, ...r });
  }, []);

  useEffect(() => {
    if (!localStorage.getItem(TOKEN_KEY)) return;
    refresh().catch(() => localStorage.removeItem(TOKEN_KEY)).finally(() => setBooting(false));
  }, [refresh]);

  const logout = () => { localStorage.removeItem(TOKEN_KEY); setSession(null); setBillingOpen(false); setView('landing'); };

  if (booting) return <div className="grid min-h-screen place-items-center text-ink-400">Cargando…</div>;

  if (session) {
    if (!session.company.access.ok || billingOpen)
      return <Billing session={session} onLogout={logout} onClose={() => setBillingOpen(false)} onCompany={(company) => setSession({ ...session, company })} />;
    return <Workspace session={session} onLogout={logout} onBilling={() => setBillingOpen(true)} onExpired={refresh} />;
  }
  if (view === 'login' || view === 'register')
    return <AuthScreen key={view} initialMode={view} onSession={setSession} onBack={() => setView('landing')} />;
  return <Landing onLogin={() => setView('login')} onRegister={() => setView('register')} />;
}
